# Editorial quality

No human ratings, reviewer IDs, rubric scores, approval sheets, or inter-reviewer-agreement records were found. Human editorial quality is therefore **unavailable**, not reconstructed from automated checks. Source: inspected `state/`, `out/`, `output/`, `docs/` retained artifacts.

Automated evidence is separate: public report-quality inspected 16 retained reports, found zero broken assets/internal-ID leaks/placeholders, but `so_what` and `now_what` coverage were both 0.0. Source: `out/cto-review-evidence/public_report_quality_local.json`.

Proposed human rubric (1–5 each): factual accuracy; evidence linkage; insight distinctiveness; decision usefulness; so-what; now-what; limitations; consultancy tone; generic-language risk (reverse); visual usefulness. Two independent reviewers per report, blind to each other; record evidence citations and compute weighted agreement.

Deterministic worksheet sample (seed `sha256('cto-v1|file_id')`, first 15): Activate 2016 outlook; Kepios Bangladesh 2024; The Moore Agency 2026; Activate China; Algolia search; Allegro 2026; Activate 2017; Kepios Abkhazia; Activate 2025 consumer internet; Capgemini 2026 retail; Kepios Namibia; Activate 2026; Skai Q4 trends; OECD Health at a Glance 2025; Activate 2025 outlook. Create `out/cto-review-evidence/editorial_review_worksheet.csv` only after human reviewer assignment; do not invent scores.
