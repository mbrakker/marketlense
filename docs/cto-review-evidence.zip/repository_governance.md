# Repository governance

Authenticated GitHub API evidence: repository is public, default branch `main`; secret scanning and push protection are enabled; Dependabot security updates are disabled; no environments were configured. `GET /branches/main/protection` returned 404 `Branch not protected`, so there are no server-enforced required checks/reviews/force-push/deletion rules for `main`. Source: GitHub API queried 2026-07-14.

`.github/CODEOWNERS`, CI workflow and pull request template are tracked. No tracked `SECURITY.md` or Dependabot configuration was found. Alert endpoints were accessible, but alert contents/counts were not used as release evidence in this pack. Branch protection is a release-governance gap.
