# Missing evidence and exact closure actions

- Acquisition publisher/latency/cost/browser consumption: add immutable `publisher`, `run_id`, `started_at`, `finished_at`, `estimated_cost`, browser counters and screenshot/snapshot IDs to route observation contracts.
- OCR/vision per report: add report ID/page/chunk/escalation reason and separate deterministic/model crop events to the usage ledger.
- Reuse savings: persist reuse decision and avoided-work counters, not only lineage state.
- WordPress remote reconciliation: provide read-only REST credential and allow GET-only verifier.
- Human quality: assign reviewers and complete the documented worksheet.
- Hosted performance: configure read-only `PUBLIC_SITE_BASE_URL` and execute the existing checker.
- SBOM: pin CycloneDX generator in dev/CI and emit it as a release artifact.
- Backup/DR: provide fixture backup, approved temporary restore target, retention/encryption/RTO/RPO policy.
- Governance: configure protected `main` required checks/reviews.
- Credential governance: document owner, rotation cadence and expiry/refresh monitoring without exposing values.
