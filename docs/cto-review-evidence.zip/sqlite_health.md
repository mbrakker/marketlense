# SQLite health

All checks used URI read-only connections with `PRAGMA query_only=ON`. `integrity_check=ok` and zero `foreign_key_check` rows are **confirmed** for every database below.

| File | Size | Journal | Tables/selected rows | Health |
|---|---:|---|---|---|
| `state/reports.sqlite` | 16,134,144 | WAL | 98 reports; 285 route rows; 40 lineage; 2,624 projection queue | ok |
| `state/signals.sqlite` | 6,680,576 | WAL | 219 signal candidates; 113 groups | ok |
| `state/llm_usage.sqlite` | 905,216 | delete | 593 usage events; 190 export checkpoints | ok |
| `state/index.sqlite` | 704,512 | WAL | 113 processed; 57 published; 37 observations | ok |
| `state/ui_runs.sqlite` | 81,920 | WAL | 4 UI runs; 3 dead letters; 6 actions | ok |
| `state/llm_usage_medians.sqlite` | 20,480 | delete | 47 medians | ok |
| 3 live-contract idempotency fixtures | 45,056 each | WAL | 1 row each | ok |

`reports.sqlite` has 3,939 pages/0 free pages/47 indexes; `index.sqlite` has 172/1/8; `llm_usage.sqlite` has 221/0/7. The projection queue is 2,624 `pending` rows, oldest `2026-04-23T05:29:54Z`, latest update `2026-07-13T06:00:08Z` (**derived**). WAL sizes, lock-wait duration, full scans, latest writes and migration failures are not reliably retained. Log text contains lock-related phrases but no structured event count or wait duration; do not treat that as a lock-rate measurement. Source: SQLite PRAGMAs and `state/reports.sqlite:vector_projection_queue`.
