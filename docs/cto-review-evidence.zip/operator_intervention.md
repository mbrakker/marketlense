# Operator intervention

Retained UI dead-letter actions total six, all attributed to `system` auto-triage in the inspected table. Three dead letters are present; observed categories include non-retryable configuration validation and replay-manifest absence. Source: `state/ui_runs.sqlite:ui_run_dead_letters,ui_run_dead_letter_actions`.

Human actor identity, request-to-action timestamps, action-to-recovery time, CAPTCHA handoff records, manual route selection, approval time, crop review and correction-review evidence are **unavailable**. Do not estimate operator time from workflow duration.
