# Command log

| Command | Exit | Duration/result |
|---|---:|---|
| `git rev-parse`, `git status`, versions | 1 | PHP unavailable; repository state captured |
| `gh run list/view/api` | 0 | remote current-head CI evidence retrieved |
| static CI checks + collection | mixed | formatting 1; WordPress PHP check 1; listed other gates 0 |
| `pytest --collect-only -q` | 0 | 3,958 collected, 25 deselected, 15.21s |
| default pytest with coverage | 124 | bounded timeout at 364.3s |
| mutation/benchmark batch | 124 | bounded timeout at 364.4s; no passing claim |
| PDF candidate benchmark | 0 | 57.08s |
| crop-refine benchmark | 0 | 0.815s, warnings only |
| public quality / routing benchmark | 0 | 2.537s / 1.751s |
| `pip check` | 0 | no broken requirements |
| `pytest tests/test_collect_cto_review_evidence.py -q` | 0 | 1 passed, 3.62s |
| evidence collector | 0 | 18.1s including scan |
| read-only SQLite PRAGMAs/queries | 0 | integrity/aggregate evidence captured |

The attempted full-suite/quality commands unexpectedly mutated tracked files; those changes were reversed before finalization. This is a confirmed test-integrity observation, not a test pass.
