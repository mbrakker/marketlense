# Hosted-site performance

No hosted checks were run: this review did not infer authorization to contact the public site, and no `PUBLIC_SITE_BASE_URL` read-only configuration snapshot was captured. **External access/configuration required.**

Existing command: `python scripts/quality/public_site_seo_performance.py --base-url $env:PUBLIC_SITE_BASE_URL --baseline config/public_site_baselines.yaml --output-json out/public_site_seo_performance_live.json`. It is documented to capture status, redirect/SEO signals, response start, DOM complete, request count, and page weight. Source: `README.md:554-583`, `scripts/quality/public_site_seo_performance.py`.
