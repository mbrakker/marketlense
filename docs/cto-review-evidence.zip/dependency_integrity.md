# Dependency integrity and SBOM

Canonical runtime declarations: `requirements.txt`; development declarations: `requirements-dev.txt`; resolved graph: `requirements.lock` (CI installs it). `pyproject.toml` requires Python >=3.12; CI uses Python 3.12.13. Local executable was Python 3.14.2; PHP CLI absent. Source: `pyproject.toml`, `.github/workflows/ci.yml`.

`python -m pip check` passed and `scripts/ci/check_dependency_consistency.py` passed (**confirmed**). No dependency update was performed. CycloneDX CLI/module was not installed (`No module named cyclonedx_py`), so no SBOM is claimed; install/use a pinned CycloneDX generator in CI to close this gap. Lock generation procedure is not explicit enough to confirm beyond the CI comment that `requirements.lock` is the sole resolved graph. Source: command log and requirements files.
