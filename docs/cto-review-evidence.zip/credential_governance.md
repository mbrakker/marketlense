# Credential governance

| External system | Credential env names | Canonical boundary | Status/visibility |
|---|---|---|---|
| OpenAI/OpenRouter | `OPENAI_API_KEY`, `OPENROUTER_API_KEY`, `OPENROUTER_HTTP_REFERER` | `src/services/_llm_service/` | `<configured>`; no expiry/rotation record |
| Google Drive/OAuth | `GOOGLE_SERVICE_ACCOUNT_JSON`, `GOOGLE_OAUTH_CLIENT_JSON`, `GOOGLE_OAUTH_TOKEN_JSON` | config/drive service | `<configured>`; no expiry monitor evidence |
| WordPress REST | `WP_SITE_URL`, `WP_USERNAME`, `WP_APP_PASSWORD`, `WP_BEARER_TOKEN` | config/publish and WordPress REST common | `<configured>`; alternative paths |
| Gmail/IMAP | `GMAIL_*`, `IMAP_*`, `MAILBOX_*` | mailbox acquisition service | `<configured>`; no owner/expiry record |

Values were not read, decoded or printed. The source has validation for credential presence in relevant configuration loaders. Committed secret-pattern scan produced path-level false-positive candidates and is not proof of hard-coded credentials; a dedicated secret scanner with verified findings is required. Expiry visibility, rotation documentation, ownership and credential inventory authority are **unavailable**. Sources: `src/services/_config_service/{drive,publish,mailbox_acquisition}.py`, `src/services/_llm_service/`.
