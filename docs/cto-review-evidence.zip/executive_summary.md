# Executive summary

Overall evidence completeness: **43% (derived)** across the 18 requested areas; the remainder is partial, unavailable, or needs external/human input. Source: [availability_matrix.csv](availability_matrix.csv).

The reviewed commit is **failing**, not green: GitHub Actions run `29365920953` for this exact SHA failed its format check at 2026-07-14T20:33:06Z; release-evidence steps were skipped. Source: [ci_evidence.md](ci_evidence.md).

Strongest confirmed capabilities:

- Canonical LLM ledger retained 598 calls, 1,476,790 total tokens and $1.125608 estimated cost (2026-07-11 through 2026-07-14). Source: `state/llm_usage.sqlite:llm_usage_events`, [llm_usage_metrics.csv](llm_usage_metrics.csv).
- Route history retained 285 route records with attempts, verified successes, route steps, outcomes and blockers. Source: `state/reports.sqlite:publisher_download_route_history`, [acquisition_metrics.csv](acquisition_metrics.csv).
- All eight inspected first-party SQLite files passed `integrity_check`; foreign-key checks returned zero rows. Source: [sqlite_health.md](sqlite_health.md).
- The PDF candidate benchmark passed all three fixtures; crop-refine signatures matched all three fixtures. Source: [ci_evidence.md](ci_evidence.md).
- Publication idempotency state is retained: 44 `publish_html` and 6 `cross_report_package` records contain published outcomes. Source: `state/index.sqlite:orchestrator_idempotency`, [wordpress_metrics.csv](wordpress_metrics.csv).

Five important gaps:

- No retained per-acquisition publisher identity, latency, cost, browser launch/navigation/screenshot/network fields.
- No human editorial ratings; quality cannot be reconstructed from automated output.
- No retained `.qa.json` crop-defect sidecars (0 found), so visual defect rate is unavailable.
- No tested backup/restore evidence or RTO/RPO record.
- No server-side branch protection; GitHub reports `main` as unprotected.

Release blocker: current-head CI format failure. Security/governance conflict: public repository, secret scanning and push protection enabled, but branch protection absent. Largest confirmed avoidable cost is not calculable because replay-suppression and avoided-work counters are not retained. Largest confirmed reliability risk is the 2,624-item pending vector projection queue, oldest 2026-04-23. Source: `state/reports.sqlite:vector_projection_queue`.

Instrumentation order: (1) append publisher/report/run/latency/cost to acquisition rows; (2) record browser launch/navigation/screenshot/network counters; (3) persist QA defect sidecars; (4) persist reuse decisions and avoided work; (5) add operator-action timestamps and an immutable human-review worksheet.

Single most valuable next action: fix the two CI formatting violations, then rerun current-head CI before relying on any release evidence.
