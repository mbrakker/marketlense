# Effective runtime configuration

Configuration precedence is YAML plus `.env` loaded by `src/services/_config_service/common.py`; selected CLI/UI arguments then override in their owners. This is a source-level conclusion, not a captured autonomous-run snapshot. Source: `src/config/app.yaml`, `src/services/_config_service/*.py`, `src/ui/settings_page.py`.

| Setting area | Default/source | Effective category | Env | Secret | Consumer/validation |
|---|---|---|---|---|---|
| LLM provider/model | `src/config/app.yaml`; model env override | `<configured>` | `OPENAI_API_KEY`, `OPENAI_MODEL`, `OPENROUTER_API_KEY` | key only | LLM service; preflight validation |
| LLM timeout/cost paths | YAML defaults | `<configured>` | `OPENAI_TIMEOUT_SECONDS`, `LLM_USAGE_DB_PATH`, `COST_LEDGER_PATH` | no | ingest/accounting; validation present |
| Drive authentication | YAML + env | `<configured>` | `GOOGLE_SERVICE_ACCOUNT_JSON`, OAuth paths | yes | drive service; mode validation |
| WordPress REST | YAML + env | `<configured>` | `WP_SITE_URL`, `WP_USERNAME`, `WP_APP_PASSWORD`/`WP_BEARER_TOKEN` | credentials | publish service; validation present |
| Browser identity/routes | `browser_download_identity.yaml`, app YAML | `<configured>` | provider keys, worker settings | mixed | browser-download service |
| Mail acquisition | app YAML + env | `<configured>` | `MAILBOX_*`, `GMAIL_*`, `IMAP_*` | credentials | mailbox service; field validation |
| Workflow retry/budgets | `app.yaml` profiles | `<configured>` | selected scalar overrides | no | workflow-control; schema validation |
| Local paths/logging | defaults plus env | `<configured>` | `STATE_DB`, `OUTPUT_DIR`, `CACHE_DIR`, `LOG_DIR` | no | services/UI |

The `.env` contains keys for the above areas, but values were not read or emitted. Exact sandbox/autonomous effective configuration, UI overrides, and profile selection are **unavailable** because retained run records do not snapshot redacted resolved settings. Multiple WordPress credential paths (app password or bearer token) and Google service-account/OAuth paths are intentional alternatives; expiry/rotation metadata is not retained.
