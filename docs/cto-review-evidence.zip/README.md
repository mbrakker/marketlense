# CTO Review Evidence Pack

Generated at 2026-07-14T20:33:12Z for commit `dd13624d1598b2ab1c8de7ea8da6b5376dc392df`.

Run `python scripts/quality/collect_cto_review_evidence.py --output-dir out/cto-review-evidence` to regenerate the retained-state CSVs without external calls. Markdown assessments pin the evidence available during this review; rerun the listed commands to refresh them. Values are redacted by category, never by secret value.

Evidence labels: **confirmed** is directly observed; **derived** is an aggregate of retained records; **inference** is explicitly qualified; **unavailable** cannot be reconstructed.
