<?php
/**
 * Title: ML - Weekly Executive Intelligence Briefing
 * Slug: marketlense/newsletter-cta
 * Categories: marketlense-home, marketlense-pages
 * Inserter: yes
 */
?>
<!-- wp:group {"className":"ml-home-section ml-briefing-cta ml-briefing-band reveal","layout":{"type":"default"}} -->
<div class="wp-block-group ml-home-section ml-briefing-cta ml-briefing-band reveal">
  <!-- wp:columns {"verticalAlignment":"center"} -->
  <div class="wp-block-columns are-vertically-aligned-center">
    <!-- wp:column {"width":"70%"} -->
    <div class="wp-block-column" style="flex-basis:70%">
      <!-- wp:group {"className":"ml-section-anchor","layout":{"type":"default"}} -->
      <div class="wp-block-group ml-section-anchor">
        <!-- wp:paragraph {"className":"ml-section-kicker ml-section-eyebrow"} -->
        <p class="ml-section-kicker ml-section-eyebrow">BRIEFING</p>
        <!-- /wp:paragraph -->
        <!-- wp:heading {"level":2,"className":"ml-section-title"} -->
        <h2 class="wp-block-heading ml-section-title">Stay close to shifting evidence.</h2>
        <!-- /wp:heading -->
        <!-- wp:html -->
        <span class="ml-section-rule" aria-hidden="true"></span>
        <!-- /wp:html -->
      </div>
      <!-- /wp:group -->
      <!-- wp:list {"className":"ml-briefing-list"} -->
      <ul class="ml-briefing-list">
        <li>New reports, briefings, publisher movement, and evidence-backed signals.</li>
        <li>Concise decision context with direct links back to published artifacts.</li>
        <li>Clear provenance and taxonomy for deeper review.</li>
      </ul>
      <!-- /wp:list -->
    </div>
    <!-- /wp:column -->

    <!-- wp:column {"width":"30%"} -->
    <div class="wp-block-column" style="flex-basis:30%">
      <!-- wp:buttons {"className":"ml-briefing-actions","layout":{"type":"flex","justifyContent":"right"}} -->
      <div class="wp-block-buttons ml-briefing-actions">
        <!-- wp:button -->
        <div class="wp-block-button"><a class="wp-block-button__link wp-element-button ml-button" href="<?php echo esc_url(home_url('/contact/')); ?>">Request updates</a></div>
        <!-- /wp:button -->
      </div>
      <!-- /wp:buttons -->
    </div>
    <!-- /wp:column -->
  </div>
  <!-- /wp:columns -->
</div>
<!-- /wp:group -->
