"""Internal semantic contract families."""
