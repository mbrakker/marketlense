"""Business/domain generators."""
