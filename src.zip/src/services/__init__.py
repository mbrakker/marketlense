"""External I/O services."""
