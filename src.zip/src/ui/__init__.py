"""Streamlit UI composition modules."""
